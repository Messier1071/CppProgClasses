
void calcpeso(){

char gen;
float height,out;
printf("insira altura \n");
scanf("%f\n",&height);

printf("f ou g\n");
scanf("%c\n",&gen);

switch (gen)
{
case 'm':
    out = (72.7 * height)-58;
    break;
case 'f':
    out = (62.1 * height)-44.7;
    break;

default:
    break;
}
printf("peso:%f",out);
return;
}