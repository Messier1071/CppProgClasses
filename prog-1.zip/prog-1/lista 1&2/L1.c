/*
Estruturas Elementares de Algoritmos
*/
#include <stdbool.h>

//soma
int soma(int a,int b){
    int c = a+b;
    return c;
}

//subtracao
int sub(int a,int b){
    int c = a-b;
    return c;
}

//multiplicacao
int mul(int a,int b){
    int c = a*b;
    return c;
}

//divisao
int div(int a,int b){
    int c = a/b;
    return c;
}

//potencia
int pot(int exp,int base){
    int c = base^exp;
    return c;
}

//bool
//and
bool and(bool b,bool a){
if(a && b){
    return true;
}
else{
    return false;
}
}
//or
bool and(bool b,bool a){
if(a || b){
    return true;
}
else{
    return false;
}
}

float lucro(float a, float b){
float c = a+(b*a);     
return c;
}



