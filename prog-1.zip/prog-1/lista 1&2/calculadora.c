#include <stdio.h>
#include <stdlib.h> 
int main(){
    
    int e,a,b,c,d;
    float cd;
    do{

    printf("escolha uma operação:\n 0-sair \n 1-soma\n 2-subtração\n 3-multiplicalção\n 4-divisão\n 5-divisão decimal\n");
    scanf("%d",&e);
    if((e>0) && (e<6)){
    printf("escolha dois numeros\n");
    scanf("%d %d",&a,&b);
        
        switch (e){
        case 1:
            c=a+b;
            printf("R:%d\n",c);
            break;
        case 2:
            c=a-b;
            printf("R:%d\n",c);
            break;
        case 3:
            c=a*b;
            printf("R:%d\n",c);
            break;
        case 4:
            c=a/b;
            if (a%b == 0)
            {
                printf("R:%d\n",c);
            }else{
                d= a%b;
                printf("R:%d \n resto %d\n",c,d);
            }
                break;
            case 5:
                cd = (float)a/(float)b;
                printf("R:%f\n",cd);
                break;
        default:
            break;
        }
    }
    }while (e!=0); 
}