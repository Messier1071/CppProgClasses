void tempo(int sec){
   int h,m,s;
        if(sec>86400){
        printf(">24h");
        return;
        }
        h = sec/3600;
        m = (sec%3600)/60;
        s = ((sec%3600)%60);
        
        printf("\n %i h,%i m & %i s",h,m,s);
return;
}