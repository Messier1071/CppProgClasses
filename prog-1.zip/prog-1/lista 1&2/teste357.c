void teste(int num){
    
    if(num%3==0){
        printf("\n divisivel por 3");}
        else{
            if ( num%5 ==0){
            printf("\n divisivel por 5");}
                else{
                    if ( num%7 ==0){
                    printf("\n divisivel por 7");
    return;
    }}}}