#include<stdio.h>

void order(int a, int b, int c){
    int max,med,min;
    int d[3];
    d[0] = a;
    d[1] = b;
    d[2] = c;

    for(int i=0;i<2;i++){
       for(int i=0;i<3;i++){
        if (d[i]>max){
            max = d[i];
        }

        if (d[i]<min){
            min = d[i];
        }

        if((d[i]<max)&&(d[i]>min)){
            med = d[i];
        }
        printf("%i",i);



    }}
    printf("\n %i, %i, %i",max,med,min);
    return;
}
