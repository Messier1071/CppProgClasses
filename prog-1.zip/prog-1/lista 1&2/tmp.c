#include <stdio.h>
#include <stdlib.h> 

void main(){
int n;
int pares;
for(int i;i<5;i++){
    scanf("%d",&n);
    
    
    if (n%2==0)
    {
        pares++;
    } 
}
printf("npares:%d",pares);
}