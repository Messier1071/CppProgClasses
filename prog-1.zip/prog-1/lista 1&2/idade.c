#include <stdio.h>
#include <stdlib.h> 
#include <stdbool.h>
#include <windows.h>
#include <math.h>
#include <time.h>


void idade(int nasc){
    int year = 2023;
    int idade = year-nasc;
    printf("\n%i",idade);

    if (idade>=16)
    {
        printf("\npode votar");
    }
    if (idade>= 18){
        printf("\npode dirigir");
    }
    



    return;
}