void bascara(float a, float b, float c){
    /*float Ra,Rb,d,f,t,g,tst;
     d = ((b*b)-4*a*c);
     f = sqrt(d);
     t = b*-1;
     g = a+a;
     Ra = (t+f)/g;
     Rb = (t-f)/g;
*/
    float Ra=((b*-1)+sqrt(((b*b)-4*a*c)))/2*a;
    float Rb=((b*-1)-sqrt(((b*b)-4*a*c)))/2*a;
    printf("\n %f, %f",Ra,Rb);
    return;
}