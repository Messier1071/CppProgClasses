#include "imports.c"

    void main(){
    printf("escolha um exercicio 1-8 \n");
    int op;
    scanf("%i",&op);
    switch (op)
    {
    case 1:
        int tmp;
        printf("insira uma idade");
        scanf("%i",&tmp);
        org(tmp);    
        break;

    case 2:
        float tmp1,tmp2,tmp3;
        printf("insira valores para A B e C\n");
        scanf("%f %f %f",&tmp1,&tmp2,&tmp3);
        printf("%f%f%f",tmp1,tmp2,tmp3);
        bascara(tmp1,tmp2,tmp3);
        break;
    
    
    default:
        break;
    }



        

        
    return;
            }

    
