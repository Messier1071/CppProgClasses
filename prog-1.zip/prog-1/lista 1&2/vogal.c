void vowel(char c){
    int tmp = 0;
    switch (c)
    {
    case 'a':
        tmp = 1;
        break;
    case 'e':
        tmp = 1;
        break;
    case 'i':
        tmp = 1;
        break;
    case 'o':
        tmp = 1;
        break;
    case 'u':
        tmp = 1;
        break;
    default:
        tmp = 0;
        break;
    }
    if(tmp == 1){
        printf("é uma vogal"); 
    }else{
        printf("não é uma vogal");
    }
    return;
}