#include <stdio.h>
#include <stdlib.h> 
#include <stdbool.h>
#include <windows.h>
#include <math.h>
#include <time.h>

#include "organizar.c"  //ex1
#include "bascara.c"    //ex2
#include "order.c"      //ex3
#include "altpeso.c"    //ex4
#include "idade.c"      //ex5
#include "horas.c"      //ex6
#include "teste357.c"   //ex7
#include "vogal.c"      //ex8