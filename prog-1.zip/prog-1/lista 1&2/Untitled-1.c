int main(/*idade*/){

    int a;
    Scanf("%i",a);


    if (a >= 5 && a<=7){ 
    printf("\n Infantil A");
    return 1;
}
    if (a >= 8 && a<=10){ 
    return 2;
    printf("\n Infantil B");
}
    if (a >= 11 && a<=13){ 
    return 3;
    printf("\n Juvenil A");
}
    if (a >= 14 && a<=17){ 
    return 4;
    printf("\n Juvenil B");
}
    if (a >18){ 
    return 5;
    printf("\n Adulto");
}}