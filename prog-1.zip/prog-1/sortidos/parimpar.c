#include <stdio.h>

void main()
{
    int n;
    printf("insira um numero\n");
    do
    {
        scanf(" %i", &n);
        switch (n)
        {
        case 0:
            break;
        default:
            if (n % 2 == 0)
            {
                printf("par\n");
            }
            else
            {
                printf("impar\n");
            }
            break;
        }
    } while (n != 0);
}