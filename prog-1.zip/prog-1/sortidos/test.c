#include <stdio.h>
#define NUM 10

void main()
{
    float a;
    while (a == 0.0)

    {
        printf("%i\n", a);
    }
}