/*
//TODO 1. Inserção de funcionário. Deve ser armazenado nome, data de nascimento, cidade e salário do funcionário.

TODO 2. Atualização de dados do funcionário.

TODO 3. Deleção do registro de um funcionário.

TODO 4. Relatório de funcionários. Deve ser exibido o nome, idade e salário de todos os funcionários.

TODO 5. Consulta por nome do funcionário. Deve ser exibido os dados do funcionário, caso ele seja encontrado.

TODO 6. Relatório de funcionários com salário maior ou igual ao salário digitado pelo usuário.

TODO 7. Relatório do número de funcionários que ganham 1 salário mínimo ou
menos, mais de 1 salário mínimo a 3 salários mínimos e mais que 3
salários mínimos.

TODO 8. Relatório do número de funcionários por cidade.
? a. Ex.:
? i. Araranguá 30 funcionários
? ii. Criciúma 10 funcionários
*/
#include <stdio.h>

typedef struct Data
{
    int dia;
    int mes;
    int ano;
} Data;

typedef struct Funcionario
{
    char nome[50];
    Data dataNascimento;
    char cidade[20];
    float salario;
} Funcionario;

Data lerData()
{
    Data data;
    printf("Digite a data de nascimento: ");
    scanf("%d/%d/%d", &data.dia, &data.mes, &data.ano);
    return data;
}

Funcionario lerFuncionario()
{
    Funcionario funcionario;
    printf("Digite o nome do funcionario: ");
    scanf("%s", funcionario.nome);
    printf("Digite a cidade do funcionario: ");
    scanf("%s", funcionario.cidade);
    printf("Digite o salario do funcionario: ");
    scanf("%f", &funcionario.salario);
    funcionario.dataNascimento = lerData();
    return funcionario;
}

void exibirFuncionario(Funcionario funcionario)
{
    printf("Nome:%10s\n", funcionario.nome);
    printf("Data de nascimento:%2i/%2i/%4i\n", funcionario.dataNascimento.dia, funcionario.dataNascimento.mes, funcionario.dataNascimento.ano);
    printf("Cidade:%10s\n", funcionario.cidade);
    printf("Salario:%10f\n", funcionario.salario);
}

void main()
{
    Funcionario a;
    a = lerFuncionario();
    exibirFuncionario(a);
}