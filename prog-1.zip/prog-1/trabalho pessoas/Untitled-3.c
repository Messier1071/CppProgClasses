#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
typedef struct batata
{
    int a;
    int b;
    char c[7];
} batata;
void checkDirectory()
{
    struct stat st = {0};

    if (stat("DATA", &st) == -1)
    {
        mkdir("DATA");
    }
}

int main(int argc, char const *argv[])
{
    checkDirectory();
    FILE *temp;
    FILE *temp2;
    int size;

    temp = fopen(".\\DATA\\func.bin", "wb");
    if (temp == NULL)
    {
        printf("Question mark ping");
    }
    batata tempo[100];

    tempo[0].a = 1;
    tempo[1].a = 2;
    tempo[0].b = 3;
    tempo[1].b = 4;
    tempo[0].c = "batata";
    size = sizeof(tempo);
    fwrite(tempo, size, 1, temp);

    printf("%i\n", size);
    // fprintf(temp, "batata");
    fclose(temp);

    temp2 = fopen(".\\DATA\\func.bin", "rb");
    batata out[2];
    fread(out, size, 1, temp2);

    printf("%i,%i,%i,%i", out[0].a, out[0].b, out[1].a, out[1].b);

    return 0;
}
