#include <stdio.h>

typedef struct Data
{
    int dia;
    int mes;
    int ano;
} Data;

int main(int argc, char const *argv[])
{
    Data b;
    b.ano = 2004;
    b.dia = 22;
    b.mes = 8;

    char batata[20];

    macaco(b, batata);

    printf(batata);

    return 0;
}

void macaco(Data a, char *p)
{
    // char *str;
    sprintf(p, "%i/%i/%i", a.dia, a.mes, a.ano);
}