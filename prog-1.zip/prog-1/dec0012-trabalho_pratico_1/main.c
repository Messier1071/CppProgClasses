#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <time.h>
#include "funcs.h"

int main()
{
    check_directory();

    int selection;
    Worker *worker_list = NULL, *aux = NULL, *HoldNext;
    char *name;

    load_files(&worker_list);

    do
    {
        selection = menu();

        switch (selection)
        {
        // 0 - Salvar e sair
        case 0:
            save_file(worker_list);
            break;

        // 1 - Cadastrar funcionario
        case 1:
            aux = create_worker();
            update_worker(aux);
            insert_worker_into_list(&worker_list, aux);
            break;

        // 2 - Atualizar cadastro
        case 2:
            printf("digite o nome do funcionario:");
            name = read_string(NULL);
            aux = search_worker_by_name(worker_list, name);
            if (aux)
            {
                HoldNext = aux->next;
                update_worker(aux); // leo vc tava resetando o campo next do funcionario
                aux->next = HoldNext;
            }
            else
            {
                printf("Funcionario não encontrado\n");
                wait();
            }
            break;
        // 3 - Remover funcionario
        case 3:
            printf("digite o nome do funcionario a remover:");
            name = read_string(NULL);
            aux = search_worker_by_name(worker_list, name);
            if (aux)
            {
                remove_worker(&worker_list, aux);
                printf("removido com sucesso\n");
            }
            else
            {
                printf("Funcionario não encontrado\n");
            }

            break;

        // 4 - Listar todos os funcionarios
        case 4:
            print_all_workers(worker_list);
            wait();
            break;

        // 5 - Pesquisa por nome
        case 5:
            printf("Digite o nome do funcionario a pesquisar:");
            name = read_string(NULL);
            aux = search_worker_by_name(worker_list, name);
            if (aux)
            {
                print_worker(aux);
            }
            else
            {
                printf("Funcionario não encontrado\n");
            }
            wait();
            break;

        // 6 - Pesquisa por salario
        case 6:
            Wage_search(worker_list);
            break;
        // 7 - Relatorio de salarios

        // 7 - Relatorio de salarios
        case 7:
            wage_report(worker_list);
            break;
            // 7 - Relatorio de salarios

            // 8 - Relatorio de funcionarios por cidade
        case 8:
            cityreport(worker_list);
            break;

        case 9:
            printf("Digite o nome do arquivo (csv) para exportar:");
            name = read_string(NULL);
            export_to_csv(worker_list, name);
            break;

        }
    } while (selection != 0);
}

