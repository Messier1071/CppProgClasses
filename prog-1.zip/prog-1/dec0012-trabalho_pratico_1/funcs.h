#include "types.h"

char *Hello_World();

int menu();

// adiciona um funcionario no começo da lista
void insert_worker_into_list(Worker **list, Worker *w);

// funcao para leitura de strings incluindo espacos em branco e removento o caractere de novalinha perdido no final
char *read_string(char *temp);

// verificacao se a pasta DATA existe na mesma pasta em que o executavel do programa se encontra para salvar os dados
void check_directory();

// cria um novo funcionario sem dados
Worker *create_worker();
// atualizar um ponteiro de funcionario
void update_worker(Worker *w);
// mostra as informações de um funcionario
void print_worker(Worker *w);
// mostra as informações de todos os funcionarios
void print_all_workers(Worker *list);
// remover um funcionario da lista
void remove_worker(Worker **list, Worker *w);
// retorna o ponteiro do funcionario com o nome especificado
Worker *search_worker_by_name(Worker *list, char *name);
// atualizar um ponteiro de funcionario
void update_worker(Worker *w);
// funcao para ler os funcionarios do arquivo e carregar na lista encadeada
void load_files(Worker **p);
// funcao para salvar a lista encadeada de funcionarios no arquivo
void save_file(Worker *p);
//"aperte enter para continuar" funcao para permitir que o usuario leia antes de continuar
void wait();
// pesquisa por salario
void Wage_search(Worker *p);
// relatorio salarios
void wage_report(Worker *p);
// exportar para csv
void export_to_csv(Worker *list, char *filename);
//relatorio de cidades*
void cityreport(Worker *List);