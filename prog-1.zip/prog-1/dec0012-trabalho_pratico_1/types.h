#define N_WORKERS 100
#define STR_SIZE 50
#define MIN_WAGE 1320

#define PATHD ".\\DATA\\Data.bin"
#define PATHN ".\\DATA\\Number.bin"

#ifdef __linux__
#define USERVAR "USER"
#define clear() system("clear")
#elif _WIN32
//#define clear() system("cls")
#define clear() for(int i = 0; i < 100; i++) printf("\n")
#define USERVAR "USERNAME"
#endif

typedef struct Date // struct para armazenar datas
{
    int d;
    int m;
    int y;
} Date;

typedef struct Worker // struct dos funcionarios
{
    char name[STR_SIZE];
    Date birthDate;
    char city[STR_SIZE];
    float wage;
    struct Worker *next;
} Worker;

typedef struct City // struct das cidades
{
    char name[STR_SIZE]; // nome da cidade
    int population;      //?contagem de funcionarios
} City;