#include "types.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys\stat.h>
#include <stdbool.h>

char *Hello_World()
{
    char *tmp = "Hello World\n";
    return tmp;
}

// escreve as opcoes e pede para o usuario escolher uma delas
int menu()
{

    int selection;
    char *options =
        "\nEscolha uma opcao:\n"
        "0 - Salvar e sair\n"                        // working
        "1 - Cadastrar funcionario\n"                // working
        "2 - Atualizar cadastro\n"                   // working
        "3 - Remover funcionario\n"                  // working aparently
        "4 - Listar todos os funcionarios\n"         // working
        "5 - Pesquisa por nome\n"                    // working
        "6 - Pesquisa por salario\n"                 //
        "7 - Relatorio de salarios\n"                //
        "8 - Relatorio de funcionarios por cidade\n" //
        "9 - Exportar dados para arquivo csv\n";     // working
    printf("bem vindo(a) ");
    printf(getenv(USERVAR));
    printf("\n");
    printf(options);
    scanf("%i", &selection);
    getchar();
    return selection;
}

// verificacao se a pasta DATA existe na mesma pasta em que o executavel do programa se encontra para salvar os dados
void check_directory()
{
    struct stat st = {0};

    if (stat(".\\DATA", &st) == -1)
    {
        mkdir("DATA");
    }
}

// funcao para leitura de strings incluindo espacos em branco e removento o caractere de novalinha perdido no final
char *read_string(char *temp)
{
    static char bufferString[STR_SIZE]; // string temporaria
    fgets(bufferString, sizeof(bufferString), stdin);
    size_t bufferSize = strlen(bufferString);
    bufferString[bufferSize - 1] = 00;
    if (temp != NULL)
    {
        strcpy(temp, bufferString);
    }

    return bufferString;
}

// funcao para ler a data digitada pelo usuario
Date read_date()
{
    Date date;
    printf("Digite a data de nascimento (dd/mm/aaaa):  ");
    scanf("%d/%d/%d", &date.d, &date.m, &date.y);
    return date;
}

// formatacao da data em uma string
char *date_to_string(Date date)
{
    static char dateString[11];
    sprintf(dateString, "%02d/%02d/%04d", date.d, date.m, date.y);
    return dateString;
}

// adiciona um funcionario no começo da lista
void insert_worker_into_list(Worker **list, Worker *w)
{
    if (*list == NULL)
    {
        *list = w;
    }
    else
    {
        w->next = *list;
        *list = w;
    }
}

// mostra as informações de um funcionario
void print_worker(Worker *w)
{
    printf("Nome: %s\n", w->name);
    printf("Cidade: %s\n", w->city);
    printf("Salario: %.2f\n", w->wage);
    printf("Data de nascimento: %s\n", date_to_string(w->birthDate));
}

// mostra as informações de todos os funcionarios
void print_all_workers(Worker *list)
{
    bool flag;
    Worker *aux = list;
    if (aux == NULL)
    {
        printf("Nenhum funcionario cadastrado\n");
        return;
    }
    while (aux)
    {
        flag = true;
        print_worker(aux);
        aux = aux->next;
        if (aux)
        {
            printf("========================================\n");
        }
    }
}

// cria um novo funcionario sem dados
Worker *create_worker()
{
    Worker *w = (Worker *)malloc(sizeof(Worker));
    w->next = NULL;
    return w;
}

// atualizar um ponteiro de funcionario
void update_worker(Worker *w)
{
    printf("Digite o nome do funcionario: ");
    read_string(w->name);
    // strcpy(w->city, read_city());
    printf("Digite a cidade do funcionario: ");
    read_string(w->city);
    printf("Digite o salario do funcionario: ");
    scanf("%f", &(w->wage));
    w->birthDate = read_date();
    w->next = NULL;
}

// remover um funcionario da lista
void remove_worker(Worker **list, Worker *w)
{
    Worker *aux = *list;
    if (*list == w)
    {
        *list = w->next;
        free(w);
    }
    else
    {
        while (aux->next != w)
        {
            aux = aux->next;
        }
        aux->next = w->next;
        free(w);
    }
}

// retorna o ponteiro do funcionario com o nome especificado
Worker *search_worker_by_name(Worker *list, char *name)
{
    Worker *aux = list;
    while (aux)
    {
        if (strcmp(aux->name, name) == 0)
        {
            return aux;
        }
        aux = aux->next;
    }
    return NULL;
}

// funcao para ler o vetor e numero de funcionarios cadastrados do arquivo
void load_files(Worker **p)
{
    Worker *aux;     // temp variable
    FILE *load_data; // file
    load_data = fopen(PATHD, "rb");

    if (load_data)
    {
        while (!feof(load_data))
        {
            aux = create_worker();
            if (fread(aux, sizeof(Worker), 1, load_data) != 1)
            {
                break;
            }

            aux->next = NULL;
            insert_worker_into_list(p, aux);
        }
    }

    fclose(load_data);
}

// funcao para salvar a lista encadeada de funcionarios cadastrados para um arquivo
void save_file(Worker *worker_list)
{
    FILE *save_data;
    save_data = fopen(PATHD, "wb");

    Worker *aux = worker_list;
    while (aux)
    {
        fwrite(aux, sizeof(Worker), 1, save_data);
        aux = aux->next;
    }
    fflush(save_data);
    fclose(save_data);
}

//"aperte enter para continuar" funcao para permitir que o usuario leia antes de continuar
void wait()
{
    printf("aperte enter para continuar");
    scanf("%c", NULL);
    getchar();
    clear();
}

void Wage_search(Worker *p)
{
    int choice = 0;
    Worker *aux = NULL;
    aux = p;

    // smaller than, bigger than , exactly
    //   void (*SearchMethod[])(Worker,float) = {Wage_search_exactly, Wage_search_bigger_than, Wage_search_smaller_than}; //an attempt to make dynamic search thingamabobs

    float query = 0;
    char *opt = "escolha um metodo de categorizacao\n" // hahah boobs
                "0 - exato\n"
                "1 - maior que\n"
                "2 - menor que\n";

    printf(opt);
    scanf("%i", &choice);
    getchar();

    if (choice > 2)
    {
        choice = 2;
    }
    if (choice < 0)
    {
        choice = 0;
    }

    printf("digite o salario a pesquisar:");
    scanf("%f", &query);
    getchar();

    while (aux)
    {
        //(*SearchMethod[choice])(*aux, query);

        switch (choice)
        {
        case 0:
            if (query = aux->wage)
            {
                print_worker(aux);
            }
            break;
        case 1:
            if (query < aux->wage)
            {
                print_worker(aux);
            }
            break;
        case 2:
            if (query > aux->wage)
            {
                print_worker(aux);
            }
            break;

        default:
            break;
        }
        aux = aux->next;
        if (aux)
        {
            printf("========================================\n");
        }
    }
    wait();
}

void wage_report(Worker *p)
{
    Worker *aux = NULL;
    aux = p;
    int a = 0, b = 0, c = 0; // contadores: 1 ou menos, 1 a 3 salarios minimos, mais de 3 salarios minimos respectivamente

    while (aux)
    {
        if (aux->wage <= MIN_WAGE)
        {
            a++;
        }
        else if (aux->wage > MIN_WAGE && aux->wage <= MIN_WAGE * 3)
        {
            b++;
        }
        else if (aux->wage > MIN_WAGE * 3)
        {
            c++;
        }
        aux = aux->next;
    }
    printf("%i recebe(m) 1 salario minimo ou menos\n", a);
    printf("%i recebe(m) 1 a 3 salarios minimos\n", b);
    printf("%i recebe(m) mais de 3 salarios minimos\n", c);

    wait();
}

// exportar para csv
void export_to_csv(Worker *list, char *filename)
{
    FILE *fp;
    fp = fopen(filename, "w");
    Worker *aux = list;
    fprintf(fp, "Nome,Cidade,Salario,Data de nascimento\n");
    while (aux)
    {
        fprintf(fp, "%s,%s,%.2f,%s\n", aux->name, aux->city, aux->wage, date_to_string(aux->birthDate));
        aux = aux->next;
    }
    fclose(fp);
}

void cityreport(Worker *List){
    int wcount = 0,ccount = 0,flag = 0,i;
    Worker *aux = List;
    while (aux)
    {
        wcount++;//conta n funcionarios
        aux = aux->next;
    }
    City *array = malloc(sizeof(City)*wcount); //vetor dinamico
    aux = List;

    for ( i = 0; i < wcount; i++)
    {
        array[i].population = 0;//limpando em caso de lixo de memoria
    }
    
    while (aux)
    {
        for (i = 0; i < wcount; i++)
        {
            if (strcasecmp(aux->city,array[i].name)==0)
            {
                flag=1;
                array[i].population++;
            }
        }
        if (flag==0)
        {
            strcpy(array[ccount].name,aux->city);
            array[ccount].population++;
            ccount++;
        }
        
        aux = aux->next;
        flag=0;
    }
    printf("relatorio do numero de fuuncionarios por cidade\n");
    for ( i = 0; i < ccount; i++)
    {
        printf(array[i].name);
        printf(":[%i]\n",array[i].population);
    }
    printf("===============================================\n");
    
    free(array);    
    wait();
}