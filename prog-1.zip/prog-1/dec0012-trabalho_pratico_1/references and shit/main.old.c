#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <time.h>

#define N_WORKERS 100
#define STR_SIZE 50
#define MIN_WAGE 1320

#define PATHD ".\\DATA\\Data.bin"
#define PATHN ".\\DATA\\Number.bin"

#ifdef __linux__
#define USERVAR "USER"
#define clear() system("clear")
#elif _WIN32
#define clear() system("cls")
#define USERVAR "USERNAME"
#endif

typedef struct Date // struct para armazenar datas
{
    int d;
    int m;
    int y;
} Date;

typedef struct Worker // struct dos funcionarios
{
    char name[STR_SIZE];
    Date birthDate;
    char city[STR_SIZE];
    float wage;
} Worker;

/*
(checagem final, o proframa deve)
0. adicionar alocação dinâmica de memória por meio de lista encadeada.
0.5 atualizar a funcao de salvar e carregar p usar lista encadeada do rep3

atuualizar o resto do codigo p funcionar com o sistema novo

1. Inserção de funcionário. Deve ser armazenado nome, data de
nascimento, cidade e salário do funcionário.
2. Atualização de dados do funcionário.
3. Deleção do registro de um funcionário.
4. Relatório de funcionários. Deve ser exibido o nome, idade e salário de
todos os funcionários.
5. Consulta por nome do funcionário. Deve ser exibido os dados do
funcionário, caso ele seja encontrado.
6. Relatório de funcionários com salário maior ou igual ao salário digitado
pelo usuário.
7. Relatório do número de funcionários que ganham 1 salário mínimo ou
menos, mais de 1 salário mínimo a 3 salários mínimos e mais que 3
salários mínimos.
8. Relatório do número de funcionários por cidade.

*/

// precisa ser uma variável global para poder ser acessada por todas as funções
int cityCount = 0;                //* número de cidades cadastradas
char cities[N_WORKERS][STR_SIZE]; //* vetor de cidades

//*prototipos de funcao
void print_worker(Worker e);
void check_directory();
void load_files(Worker *p, int *i, int size);
void save_file(Worker *p, int *i, int size);
void report(int num, Worker *p);
void update_worker(int num, Worker *p);
void wait();
void remove_worker(int *num, Worker *p);
void wage_search(int N, Worker *p);
void name_search(int N, Worker *p);
void wage_report(int N, Worker *p);
void city_report(int N, Worker *p);
void load_cities(Worker _workers[N_WORKERS], int count);
Worker read_worker();
Date read_date();
char *date_to_string(Date date);
char *read_string(char *temp);
char *read_city();
int get_age(Date date);
int mkdir(const char *pathname);
int menu();
int get_worker_position_by_name(int num, Worker *p);
bool array_contains_string(char array[][STR_SIZE], int count, char *string);
//* fim prototipos

int main()
{
    // startup
    int nWorkers = 0, selection = 0;      //*nworkers ta armazenando o "ID" da proxima posicao vazia
    check_directory();                    //*checa e cria a pasta DATA
    Worker workers[N_WORKERS];            //*vetor de funcionarios
    char cities[N_WORKERS][STR_SIZE];     //*vetor de cidades
    const size_t size = sizeof(workers);  //*constante necessaria para salvar e ler (tamanho do vetor em bytes)
    load_files(workers, &nWorkers, size); //*preenche o vetor com os dados salvos
    load_cities(workers, nWorkers);
    //  startup end

    do
    {
        selection = menu();
        switch (selection)
        {
        case 1:
            if (nWorkers < N_WORKERS)
            {
                workers[nWorkers] = read_worker();
                nWorkers++;
            }
            else
            {
                printf("limite de funcionarios atingido");
                wait();
            }
            clear();
            break;
        case 2:
            update_worker(nWorkers, workers);
            break;
        case 3:
            remove_worker(&nWorkers, workers);
            break;
        case 4:
            report(nWorkers, workers);
            break;
        case 5:
            name_search(nWorkers, workers);
            break;
        case 6:
            wage_search(nWorkers, workers);
            break;
        case 7:
            wage_report(nWorkers, workers);
            break;
        case 8:
            clear();
            city_report(nWorkers, workers);
            break;
        default:
            break;
        }
    } while (selection != 0);
    save_file(workers, &nWorkers, size);
    return 0;
}

// escreve os dados do funcionario na tela
void print_worker(Worker e)
{
    printf("\nNome: %s\n", e.name);
    // printf("Data de nascimento: %s\n", date_to_string(e.birthDate));
    printf("Idade: %i\n", get_age(e.birthDate));
    printf("Cidade: %s\n", e.city);
    printf("Salario: %.2f\n", e.wage);
}
// escolha ou cadastro de cidade
char *read_city()
{
    int i, choice;
    printf("Escolha uma cidade: \n");
    for (i = 0; i < cityCount; i++)
    {
        printf("[%d] %s\n", i + 1, cities[i]);
    }
    printf("[0] Adicionar nova cidade\n");

    scanf("%d", &choice);
    getchar();
    if (choice == 0)
    {
        // lê uma nova cidade e adiciona ao vetor de cidades
        printf("Digite o nome da cidade: ");
        char *newCity = read_string(NULL);
        strcpy(cities[cityCount], newCity);
        cityCount++;
        return cities[cityCount - 1];
    }
    else
    {
        return cities[choice - 1]; // retorna a cidade escolhida (-1 para facilitar a entrada do usuário)
    }
}
// cadastro do funcionario
Worker read_worker()
{
    Worker e;
    printf("Digite o nome do funcionario: ");
    read_string(e.name);
    strcpy(e.city, read_city());
    printf("Digite o salario do funcionario: ");
    scanf("%f", &e.wage);
    e.birthDate = read_date();
    return e;
}
// verificacao se a pasta DATA existe na mesma pasta em que o executavel do programa se encontra para salvar os dados
void check_directory()
{
    struct stat st = {0};

    if (stat(".\\DATA", &st) == -1)
    {
        mkdir("DATA");
    }
}
// funcao para ler a data digitada pelo usuario
Date read_date()
{
    Date date;
    printf("Digite a data de nascimento (dd/mm/aaaa):  ");
    scanf("%d/%d/%d", &date.d, &date.m, &date.y);
    return date;
}
// formatacao da data em uma string
char *date_to_string(Date date)
{
    static char dateString[11];
    sprintf(dateString, "%02d/%02d/%04d", date.d, date.m, date.y);
    return dateString;
}
// encontra a posicao do vetor pelo nome digitado pelo usuario
int get_worker_position_by_name(int num, Worker *p)
{
    char *name = read_string(NULL);
    int i;
    for (i = 0; i < num; i++)
    {
        if (strcmp(p[i].name, name) == 0)
        {
            return i;
        }
    }
    return -1;
}
// funcao para contar e carregar as cidades em um vetor
void load_cities(Worker _workers[N_WORKERS], int count)
{
    int i, j;
    bool flag;
    for (i = 0; i < count; i++)
    {
        if (!array_contains_string(cities, cityCount, _workers[i].city))
        {
            strcpy(cities[cityCount], _workers[i].city);
            cityCount++;
        }
    }
}
// funcao para checar se uma string esta em um vetor de strings
bool array_contains_string(char array[][STR_SIZE], int count, char *string)
{
    int i;

    for (i = 0; i < count; i++)
    {
        if (strcmp(array[i], string) == 0)
        {
            return true;
        }
    }
    return false;
}

// recebe uma data e retorna a idade atual
int get_age(Date date)
{
    // converter a data para segundos
    time_t birthDate = mktime(&(struct tm){.tm_year = date.y - 1900, .tm_mon = date.m - 1, .tm_mday = date.d});
    // converter a data atual para segundos
    time_t now = time(NULL);
    // calcular a diferença entre as duas datas em segundos
    double diff = difftime(now, birthDate);
    // converter a diferença para anos
    int age = diff / (60 * 60 * 24 * 365.25);
    return age;
}

// escreve as opcoes e pede para o usuario escolher uma delas
int menu()
{

    int selection;
    char *options =
        "\nEscolha uma opcao:\n"
        "0 - Salvar e sair\n"
        "1 - Cadastrar funcionario\n"
        "2 - Atualizar cadastro\n"
        "3 - Remover funcionario\n"
        "4 - Listar todos os funcionarios\n"
        "5 - Pesquisa por nome\n"
        "6 - Pesquisa por salario\n"
        "7 - Relatorio de salarios\n"
        "8 - Relatorio de funcionarios por cidade\n";
    printf("bem vindo(a) ");
    printf(getenv(USERVAR));
    printf("\n");
    printf(options);
    scanf("%i", &selection);
    getchar();
    return selection;
}
// funcao para ler o vetor e numero de funcionarios cadastrados do arquivo
void load_files(Worker *p, int *i, int size)
{
    FILE *loadData, *loadNumber;
    loadData = fopen(PATHD, "rb");
    loadNumber = fopen(PATHN, "rb");
    fread(p, size, 1, loadData);
    fread(i, 4, 1, loadNumber);
    fclose(loadData);
    fclose(loadNumber);
}
// funcao para salvar o vetor e numero de funcionarios cadastrados para um arquivo
void save_file(Worker *p, int *i, int size)
{
    FILE *saveData, *saveNumber;
    saveData = fopen(PATHD, "wb");
    saveNumber = fopen(PATHN, "wb");

    fwrite(p, size, 1, saveData);
    fwrite(i, 4, 1, saveNumber);
    fclose(saveData);
    fclose(saveNumber);
}
//"ToString" escreve todos os funcionarios na tela para consulta
void report(int num, Worker *worker)
{
    int i = 0;
    printf("\n-----relatorio-----\n");
    for (i = 0; i < num; i++)
    {
        print_worker(worker[i]);
    }
    printf("\n---fim relatorio---\n");
    wait();
}
// funcao para leitura de strings incluindo espacos em branco e removento o caractere de novalinha perdido no final
char *read_string(char *temp)
{
    static char bufferString[STR_SIZE]; // string temporaria
    fgets(bufferString, sizeof(bufferString), stdin);
    size_t bufferSize = strlen(bufferString);
    bufferString[bufferSize - 1] = 00;
    if (temp != NULL)
    {
        strcpy(temp, bufferString);
    }

    return bufferString;
}
// sobreescreve os dados do funcionario
void update_worker(int num, Worker *p)
{
    printf("insira o nome do funcionario a ser modificado: ");
    int id = get_worker_position_by_name(num, p);
    p[id] = read_worker();
    clear();
    return;
}
//"aperte enter para continuar" funcao para permitir que o usuario leia antes de continuar
void wait()
{
    printf("aperte enter para continuar");
    scanf("%c", NULL);
    clear();
}
// remove um funcionario do "banco de dados"
void remove_worker(int *N, Worker *p)
{
    char op;
    printf("insira o nome do funcionario: ");
    int pos = get_worker_position_by_name(*N, p);
    if (pos == -1)
    {
        printf("não encontrado");
        return;
    }
    print_worker(p[pos]);
    printf("confirma a deleção? [S/N]");
    scanf("%c", &op);
    getchar();
    if (op == 'S' || op == 's')
    {
        for (size_t i = pos; i < *N; i++)
        {
            p[i] = p[i + 1];
        }
        *N = *N - 1;
        printf("apagado com sucesso\n");
    }

    clear();
}
// pesquisa quantos funcionarios tem um salario maior ou igual que o digitado
void wage_search(int N, Worker *p)
{
    float search;
    int count = 0;
    printf("digite um valor para pesquisar:");
    scanf("%f", &search);
    getchar();

    for (size_t i = 0; i < N; i++)
    {
        if (p[i].wage >= search)
        {
            count++;
        }
    }
    if (count == 0)
    {
        printf("nenhum funcionario recebe %fR$ ou mais\n", count, search);
    }
    else if (count == 1)
    {
        printf("%i funcionario recebe %fR$ ou mais\n", count, search);
    }
    else
    {
        printf("%i funcionarios recebem %fR$ ou mais\n", count, search);
    }

    wait();
}
// pesquisa o funcionario pelo nome completo
void name_search(int N, Worker *p)
{
    printf("insira o nome do funcionario: ");
    int id = get_worker_position_by_name(N, p);
    if (id == -1)
    {
        printf("\nNao encontrado\n");
    }
    else
    {
        print_worker(p[id]);
    }
    wait();
}
// lista o numero de funcionarios pelo n° de salarios minimos
void wage_report(int N, Worker *p)
{
    int a = 0, b = 0, c = 0; // contadores: 1 ou menos, 1 a 3 salarios minimos, mais de 3 salarios minimos respectivamente

    for (size_t i = 0; i < N; i++)
    {
        if (p[i].wage <= MIN_WAGE)
        {
            a++;
        }
        else if (p[i].wage > MIN_WAGE && p[i].wage <= MIN_WAGE * 3)
        {
            b++;
        }
        else if (p[i].wage > MIN_WAGE * 3)
        {
            c++;
        }
    }
    printf("%i recebe(m) 1 salario minimo ou menos\n", a);
    printf("%i recebe(m) 1 a 3 salarios minimos\n", b);
    printf("%i recebe(m) mais de 3 salarios minimos\n", c);

    wait();
}
// lista o numero de funcionarios por cidade
void city_report(int N, Worker *p)
{
    int workersByCity[cityCount];

    for (size_t i = 0; i < cityCount; i++)
    {
        workersByCity[i] = 0;
    }

    for (size_t i = 0; i < cityCount; i++)
    {
        for (size_t j = 0; j < N; j++)
        {
            if (strcmp(cities[i], p[j].city) == 0)
            {
                workersByCity[i]++;
            }
        }
    }

    for (size_t i = 0; i < cityCount; i++)
    {
        if (workersByCity[i] > 0)
            printf("%s: %i funcionarios\n", cities[i], workersByCity[i]);
    }
    wait();
}
