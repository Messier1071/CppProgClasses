#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char const *argv[])
{
    srand(time(NULL));
    int N;
    printf("quantos numeros deseja criar:");
    scanf("%i", &N);
    getchar();
    // int *p = malloc(sizeof(int) * N);

    int p = 0;
    FILE *odd = NULL, *even = NULL;
    int i;
    odd = fopen("odd.txt", "w");
    even = fopen("even.txt", "w");

    for (i = 0; i < N; i++)
    {
        p = rand();
        if (p % 2 == 0)
        {
            fprintf(even, "%i\n", p);
        }
        else
        {
            fprintf(odd, "%i\n", p);
        }
    }
    fflush(odd);
    fflush(even);
    fclose(odd);
    fclose(even);

    return 0;
}
