#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct coordinates
{
    int x;
    int y;
    struct coordinates *next;
} coord;

void *Register(coord **list);
coord filler();
void out(coord **list);
void delete(int remove_x, int remove_y, coord **file);

int main(int argc, char const *argv[])
{
    coord *list = NULL;
    srand(time(NULL));
    int nr_registros = 0, i, opt = 0, remove_x = 0, remove_y = 0;
    scanf("%i", &nr_registros);
    getchar();
    for (i = 0; i < nr_registros; i++)
    {
        Register(&list);
    }

    do
    {
        out(&list);
        printf("deseja remover um dado?(0,1):");
        scanf("%i", &opt);
        getchar();
        if (opt == 0)
        {
            printf("adios");
            break;
        }
        else
        {
            printf("insira as coordenadas do ponto a ser removido:\n");
            printf("X:");
            scanf("%i", &remove_x);
            getchar();
            printf("Y:");
            scanf("%i", remove_y);
            getchar();
            delete (remove_x, remove_y, &list);
        }
    } while (opt != 0);

    return 0;
}

void delete(int remove_x, int remove_y, coord **list)
{
    coord *aux = NULL, *last = NULL;
    aux = (*list);

    while (aux)
    {
        if (aux->x == remove_x && aux->y == remove_y)
        {
            if (last == NULL)
            {
                (*list) = aux->next;
            }
            else
            {
                last->next = aux->next;
            }
        }
        else
        {
            last = aux;
            aux = aux->next;
        }
    }
}

void *Register(coord **file)
{
    coord *aux = NULL;
    aux = malloc(sizeof(coord));
    *aux = filler();
    if (file)
    {
        aux->next = (*file);
        (*file) = aux;
    }
    else
    {
        (*file) = aux;
    }
}

coord filler()
{
    coord temp;
    temp.x = rand() % 100;
    temp.y = rand() % 100;
    temp.next = NULL;
    return temp;
}

void out(coord **list)
{
    coord *aux = (*list);
    while (aux)
    {
        printf("x:%i\n", aux->x);
        printf("y:%i\n", aux->y);
        printf("p:%p\n", aux->next);
        aux = aux->next;
    }
}