#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void main()
{

    char test[5][10];

    strcpy(test[0], "arroz");
    strcpy(test[1], "feijao");
    strcpy(test[2], "bife");
    strcpy(test[3], "espaguete");
    strcpy(test[4], "ovo");

    char *batata = "espaguete";
    array_contains_string(test, 5, batata);
}

int array_contains_string(char array[][50], int count, char *string)
{
    int i;
    char *bat = "geraldos";
    char *tmp = "ana";
    int a = 350, b = 450;

    printf("%10s %3i\n", bat, a);
    printf("%10s %3i\n", tmp, b);

    return 0;
}