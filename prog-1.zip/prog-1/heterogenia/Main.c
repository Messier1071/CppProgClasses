#include <stdio.h>
#include <stdlib.h>

typedef struct student
{
    int ID;
    float NF;
} Aluno;
#define Num 10

int main(int argc, char const *argv[])
{
    int i;
    Aluno lista[Num];
    for (i = 0; i < Num; i++)
    {
        printf("insira a matricula \n");
        scanf("%i", &lista[i].ID);
        printf("insira a nota \n");
        scanf("%f", &lista[i].NF);
    }
    /* for (i = 0; i < Num; i++)
    {
        if (lista[i].NF >= 6)
        {
            printf("%i esta aprovado\n", lista[i].ID);1
        }
        else if (3 < lista[i].NF && lista[i].NF <= 5.9)
        {
            printf("%i esta em recuperacao\n", lista[i].ID);
        }
        else if (lista[i].NF <= 3)
        {
            printf("%i esta reprovado", lista[i].ID);
        }
    }*/

    
        printf("-------aprovados-------\n");
        for (i = 0; i < Num; i++)
        {
            if (lista[i].NF >= 6)
            {
                printf("%i esta aprovado\n", lista[i].ID);
            }
        }

        printf("-------Recuperação-------\n");
        for (i = 0; i < Num; i++)
        {
            if (3 < lista[i].NF && lista[i].NF <= 5.9)
            {
                printf("%i esta em recuperacao\n", lista[i].ID);
            }
        }

        printf("-------Reprovado-------\n");
        for (i = 0; i < Num; i++)
        {
            if (lista[i].NF <= 3)
            {
                printf("%i esta reprovado", lista[i].ID);
            }
        }
    
    return 0;
}
