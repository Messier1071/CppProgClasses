#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main(){

}

/*
export function decrypt(encrypted: string, password: string, removeIndicator: boolean): string {
    const decrypted = steggo.reveal(encrypted, password);
    return removeIndicator ? decrypted.replace("\u200b", "") : decrypted;
}





*/