#include "Funcs.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char const *argv[])
{
    printf("%p", read_Product);
    int opt;
    Product *temp, *DBS = NULL, *DBE = NULL, *scan = NULL;
    do
    {
        opt = menu();

        switch (opt)
        {
        case 1:
            temp = allocate_mem();
            int op;
            *temp = read_Product();
            if (DBS == NULL)
            {
                DBS = temp;
                DBS->next = NULL;
                printf("alocado automaticamente...");
                break;
            }
            if (DBE == NULL)
            {
                DBE = temp;
                DBS->next = DBE;
                DBE->next = NULL;
                printf("alocado automaticamente...");
                break;
            }

            printf("\n0 - inserir no comeco\n1 - inserir no final\n");
            scanf("%i", &op);
            getchar();

            if (op == 0)
            {

                temp->next = DBS;
                DBS = temp;
            }
            else if (op == 1)
            {

                DBE->next = temp;
                DBE = temp;
                DBE->next = NULL;
            }
            break;
        case 2:
            scan = DBS;
            if (DBS == NULL)
            {
                break;
            }

            do
            {
                print_product(*scan);
                temp = scan->next;
                scan = temp;
            } while (scan);

            break;

        default:
            break;
        }
    } while (opt != 0);

    return 0;
}
