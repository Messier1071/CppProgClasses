#define Str_Size 50

typedef struct String
{
    char text[Str_Size];
} String;

typedef struct Product
{
    String name;
    int stock;
    float price;
    struct Product *next;
} Product;