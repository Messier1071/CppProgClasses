#include "types.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

String read_String(String *Out)
{
    String nul = {00};
    if (Out->text == NULL)
    {
        static String Temp;
        fgets(Temp.text, sizeof(Temp.text), stdin);
        Temp.text[(int)strlen((char *)Temp.text) - 1] = 00;
        return Temp;
    }
    else
    {
        fgets(Out->text, sizeof(Out->text), stdin);
        Out->text[(int)strlen((char *)Out->text) - 1] = 00;
        return nul;
    }
}
Product read_Product()
{
    Product temp;
    printf("Digite o nome do produto:");
    temp.name = read_String(NULL);
    printf("Digite o preco do produto:");
    scanf("%f", &temp.price);
    getchar();
    printf("Digite o estoque do produto:");
    scanf("%i", &temp.stock);
    getchar();
    return temp;
}
void print_product(Product out)
{
    printf("\nNome: ");
    printf(out.name.text);
    printf("\nValor unitario: %.2f", out.price);
    printf("\nEstoque: %i\n\n", out.stock);
}
int menu()
{
    int opt;
    char *options =
        "\nEscolha uma opcao:\n"
        "0 - Sair\n"
        "1 - Cadastrar produto\n"
        "2 - Listar todos os produtos\n";
    printf(options);
    scanf("%i", &opt);
    getchar();
    return opt;
}
Product *allocate_mem()
{
    Product *temp = (Product *)malloc(sizeof(Product));
    return temp;
}