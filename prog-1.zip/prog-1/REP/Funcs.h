#include "types.h"

String read_String(String *Out);
Product read_Product();
void print_product(Product out);
int menu();
Product *allocate_mem();