#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct dados_letra
{
    char letra;
    int codigo_tabela_ASCII;
    struct dados_letra *proximo;
};

int main()
{

    return 0;
}
