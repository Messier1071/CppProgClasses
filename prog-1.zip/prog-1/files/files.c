#include <stdio.h>
#include <stdlib.h>

void main()
{
    FILE *p = NULL;
    p = fopen("text.txt", "w+");
    int a = 0;

    scanf("%i", &a);
    fprintf(p, "%i", a);
    rewind(p);
    int b = 0;
    fscanf(p, "%i", &b);
    printf("%i", b);
}