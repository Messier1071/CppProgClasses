#include <stdio.h>
#include <stdlib.h>

typedef struct string
{
    char text[50];
} String;

void main()
{
    String texto = {"batata"};
    String *p = &texto;

    printf(texto.text);
    printf("/n");
    printf(p->text);
    printf("/n");
    func(&p);
}

void func(String **p)
{
    printf((*p)->text);
}