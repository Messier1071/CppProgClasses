using System;
namespace atleta
{
    class Program
    {
        private static void Main(string[] args)
        {
            Console.Clear();
            Console.WriteLine("Idades atletas\n\n");
            string entrada = "";
            int idade = 0;

            Console.WriteLine("Insira a idade: ");
            entrada = Console.ReadLine();

            idade = Int32.Parse(entrada);



            switch (day)
            {
                case < 6:
                    Console.WriteLine("Today is Saturday.");
                    break;
                case 7:
                    Console.WriteLine("Today is Sunday.");
                    break;
                default:
                    Console.WriteLine("Looking forward to the Weekend.");
                    break;
            }

            if (idade < 5)
            {
                Console.WriteLine("Jovem demais para competir!");
            }
            else if (idade < 8)
            {
                Console.WriteLine("Categoria i: Infantil A");
            }
            else if (idade <= 10)
            {
                Console.WriteLine("Categoia ii: Infantil B");
            }
            else if (idade <= 13)
            {
                Console.WriteLine("Categoria iii: Juvenil A");
            }
            else if (idade <= 17)
            {
                Console.WriteLine("Categoria iv: Juvenil B");
            }
            else if (idade > 18)
            {
                Console.WriteLine("Categoria V- Sênior");
            }

        }
    }
}