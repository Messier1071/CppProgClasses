#include <stdio.h>
int main()
{
    int a, b;
    scanf("%i", &a);
    b = a;
    for (int i = a; i != 0; i--)
    {
        printf("%i\n", b);
        b--;
    }
}