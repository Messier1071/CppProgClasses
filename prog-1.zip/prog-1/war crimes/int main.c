#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>

#define N_WORKERS 100
#define STR_SIZE 50
#define PATHD ".\\DATA\\Data.bin"
#define PATHN ".\\DATA\\Number.bin"

#ifdef __linux__
#define clear() system("clear")
#elif _WIN32
#define clear() printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
#endif
// system("cls")

//// 1. Inserção de funcionário. Deve ser armazenado nome, data de nascimento, cidade e salário do funcionário.
typedef struct Date // struct para armazenar datas
{
    int d;
    int m;
    int y;
} Date;

typedef struct Worker // struct dos funcionarios
{
    char name[STR_SIZE];
    Date birthDate;
    char city[STR_SIZE];
    float wage;
} Worker;

//*prototipos de funcao (sim eu to organizando por tipo)
void print_worker(Worker e);
void check_directory();
void load_files(Worker *p, int *i, int size);
void save_file(Worker *p, int *i, int size);
void report(int num, Worker *p);
void update_worker(int num, Worker *p, int *nCities, char *cities);
void wait();
void remove_worker(int *num, Worker *p);
void wage_search(int N, Worker *p);
void name_search(int N, Worker *p);
void wage_report(int N, Worker *p);
Worker read_worker(int *cityCount, char cities[STR_SIZE]);
Date read_date();
char *date_to_string(Date date);
char *read_string(char *temp);
char *read_city(int *cityCount, char cities[STR_SIZE]);
int mkdir(const char *pathname);
int menu();
int get_worker_position_by_name(int num, Worker *p);
void load_cities(Worker _workers[N_WORKERS], int nWorkers, char *cities, int *nCities); // funcao para contar e carregar as cidades em um vetor
bool array_contains_string(char *array, int count, char *string);
//* fim prototipos

//// funcao de imout de strings sem newline no fim
//// 2. Atualização de dados do funcionário.
//// 3. Deleção do registro de um funcionário.
//// 4. Relatório de funcionários. Deve ser exibido o nome, idade e salário de todos os funcionários.
////  5. Consulta por nome do funcionário. Deve ser exibido os dados do funcionário, caso ele seja encontrado.
//// 6. Relatório de funcionários com salário maior ou igual ao salário digitado pelo usuário.
//// 7. Relatório do número de funcionários que ganham 1 salário mínimo ou
//// menos, mais de 1 salário mínimo a 3 salários mínimos e mais que 3 salários mínimos.

// TODO 8. Relatório do número de funcionários por cidade.
//*a. Ex.:
//*i. Araranguá 30 funcionários
//*ii. Criciúma 10 funcionários

int main()
{

    // startup
    char *cities[N_WORKERS][STR_SIZE];
    int nWorkers = 0, nCities = 0, selection = 0;     //*nworkers ta armazenando o "ID" da proxima posicao vazia
    check_directory();                                //*checa e cria a pasta DATA
    Worker workers[N_WORKERS];                        //*vetor de funcionarios
    const size_t size = sizeof(workers);              //*constante necessaria para salvar e ler (tamanho do vetor em bytes)
    load_files(workers, &nWorkers, size);             //*preenche o vetor com os dados salvos
    load_cities(workers, nWorkers, cities, &nCities); //* carrega as cidades em um vetor
    //  startup end

    do
    {
        selection = menu();
        switch (selection)
        {
        case 1:
            if (nWorkers < 100)
            {
                workers[nWorkers] = read_worker(&nCities, cities);
                nWorkers++;
            }
            clear();
            break;
        case 2:
            update_worker(nWorkers, workers, &nCities, cities);
            break;
        case 3:
            remove_worker(&nWorkers, workers);
            break;
        case 4:
            report(nWorkers, workers);
            break;
        case 5:
            name_search(nWorkers, workers);
            break;
        case 6:
            wage_search(nWorkers, workers);
            break;
        case 7:
            wage_report(nWorkers, workers);
            break;

        default:
            break;
        }
    } while (selection != 0);
    save_file(workers, &nWorkers, size);
    return 0;
}

// escreve os dados do funcionario na tela
void print_worker(Worker e)
{
    printf("\nNome: %s\n", e.name);
    printf("Data de nascimento: %s\n", date_to_string(e.birthDate));
    printf("Cidade: %s\n", e.city);
    printf("Salario: %.2f\n", e.wage);
}

char *read_city(int *cityCount, char cities[STR_SIZE])
{
    int i, choice;
    printf("Escolha uma cidade: \n");
    for (i = 0; i < *cityCount; i++)
    {
        printf("[%d] %s\n", i + 1, cities[i]);
    }
    printf("[0] Adicionar nova cidade\n");

    scanf("%d", &choice);
    getchar();
    if (choice == 0)
    {
        // lê uma nova cidade e adiciona ao vetor de cidades
        printf("Digite o nome da cidade: ");
        char *newCity;
        // newCity//
        cities[*cityCount] = read_string(NULL);
        // strcpy(cities[*cityCount], newCity);
        cityCount++;
        return cities[*cityCount - 1];
    }
    else
    {
        return cities[choice - 1]; // retorna a cidade escolhida (-1 para facilitar a entrada do usuário)
    }
}
// cadastro do funcionario
Worker read_worker(int *cityCount, char cities[STR_SIZE])
{
    Worker e;
    printf("Digite o nome do funcionario: ");
    read_string(e.name);
    printf("Digite a cidade do funcionario: ");
    strcpy(e.city, read_city(cityCount, cities));
    printf("Digite o salario do funcionario: ");
    scanf("%f", &e.wage);
    e.birthDate = read_date();
    return e;
}
// verificacao se a pasta DATA existe na mesma pasta em que o executavel do programa se encontra para salvar os dados
void check_directory()
{
    struct stat st = {0};

    if (stat(".\\DATA", &st) == -1)
    {
        mkdir("DATA");
    }
}
// funcao para ler a data digitada pelo usuario
Date read_date()
{
    Date date;
    printf("Digite a data de nascimento: ");
    scanf("%d/%d/%d", &date.d, &date.m, &date.y);
    return date;
}
// formatacao da data em uma string
char *date_to_string(Date date)
{
    static char dateString[11];
    sprintf(dateString, "%02d/%02d/%04d", date.d, date.m, date.y);
    return dateString;
}
// encontra a posicao do vetor pelo nome digitado pelo usuario
int get_worker_position_by_name(int num, Worker *p)
{
    char *name = read_string(NULL);
    int i;
    for (i = 0; i < num; i++)
    {
        if (strcmp(p[i].name, name) == 0)
        {
            return i;
        }
    }
    return -1;
}

void load_cities(Worker _workers[N_WORKERS], int nWorkers, char *cities, int *nCities) // funcao para contar e carregar as cidades em um vetor
{
    int i, j;
    bool flag;
    for (i = 0; i < nWorkers; i++)
    {
        if (!array_contains_string(cities, *nCities, _workers[i].city))
        {
            strcpy(cities[*nCities], _workers[i].city);
            *nCities++;
        }
    }

    for (int k = 0; k < *nCities; k++)
    {
        printf("%s\n", cities[k]);
    }
}

bool array_contains_string(char *array, int count, char *string) // funcao para checar se uma string esta em um vetor de strings
{
    int i;

    for (i = 0; i < count; i++)
    {
        if (strcmp(array[i], string) == 0)
        {
            return true;
        }
    }
    return false;
}
// escreve as opcoes e pede para o usuario escolher uma delas
int menu()
{

    int selection;
    char *options =
        "\n0 - salvar e sair\n"                       //
        "1 - cadastrar funcionario\n"                 //
        "2 - atualizar cadastro\n"                    //
        "3 - remover funcionario\n"                   //
        "4 - relatorio\n"                             // dump do vetor
        "5 - Pesquisa por nome\n"                     //
        "6 - pesquisa por salario\n"                  //
        "7 - relatorio de salarios\n"                 //
        "8 - relatorio de funcionarios por cidade\n"; //
    printf(options);
    scanf("%i", &selection);
    getchar();
    return selection;
}
// funcao para ler o vetor e numero de funcionarios cadastrados do arquivo
void load_files(Worker *p, int *i, int size)
{
    FILE *loadData, *loadNumber;
    loadData = fopen(PATHD, "rb");
    loadNumber = fopen(PATHN, "rb");
    fread(p, size, 1, loadData);
    fread(i, 4, 1, loadNumber);
    fclose(loadData);
    fclose(loadNumber);
}
// funcao para salvar o vetor e numero de funcionarios cadastrados para um arquivo
void save_file(Worker *p, int *i, int size)
{
    FILE *saveData, *saveNumber;
    saveData = fopen(PATHD, "wb");
    saveNumber = fopen(PATHN, "wb");

    fwrite(p, size, 1, saveData);
    fwrite(i, 4, 1, saveNumber);
    fclose(saveData);
    fclose(saveNumber);
}
//"ToString" escreve todos os funcionarios na tela para consulta
void report(int num, Worker *worker)
{
    int i = 0;
    printf("\n-----relatorio-----\n");
    for (i = 0; i < num; i++)
    {
        print_worker(worker[i]);
    }
    printf("\n---fim relatorio---\n");
    wait();
}
// funcao para leitura de strings incluindo espacos em branco e removento o caractere de novalinha perdido no final
char *read_string(char *temp)
{
    static char bufferString[STR_SIZE]; // string temporaria
    fgets(bufferString, sizeof(bufferString), stdin);
    size_t bufferSize = strlen(bufferString);
    bufferString[bufferSize - 1] = 00;
    if (temp != NULL)
    {
        strcpy(temp, bufferString);
    }

    return bufferString;
}
// sobreescreve os dados do funcionario
void update_worker(int num, Worker *p, int *nCities, char *cities)
{
    printf("insira o nome do funcionario a ser modificado: ");
    int id = get_worker_position_by_name(num, p);
    p[id] = read_worker(nCities, cities);
    clear();
    return;
}
//"aperte enter para continuar" funcao para permitir que o usuario leia antes de continuar
void wait()
{
    printf("aperte enter para continuar");
    scanf("%c", NULL);
    clear();
}
// remove um funcionario do "banco de dados"
void remove_worker(int *N, Worker *p)
{
    char op;
    printf("insira o nome do funcionario: ");
    int pos = get_worker_position_by_name(*N, p);
    if (pos == -1)
    {
        printf("não encontrado");
        return;
    }
    print_worker(p[pos]);
    printf("confirma a deleção? [S/N]");
    scanf("%c", &op);
    getchar();
    if (op == 'S' || op == 's')
    {
        for (size_t i = pos; i < *N; i++)
        {
            p[i] = p[i + 1];
        }
        *N = *N - 1;
        printf("apagado com sucesso\n");
    }

    clear();
}
// pesquisa quantos funcionarios tem um salario maior ou igual que o digitado
void wage_search(int N, Worker *p)
{
    float search;
    int count = 0;
    printf("digite um valor para pesquisar:");
    scanf("%f", &search);
    getchar();

    for (size_t i = 0; i < N; i++)
    {
        if (p[i].wage >= search)
        {
            count++;
        }
    }
    if (count == 0)
    {
        printf("nenhum funcionario recebe %fR$ ou mais\n", count, search);
    }
    else if (count == 1)
    {
        printf("%i funcionario recebe %fR$ ou mais\n", count, search);
    }
    else
    {
        printf("%i funcionarios recebem %fR$ ou mais\n", count, search);
    }

    wait();
}
// pesquisa o funcionario pelo nome completo
void name_search(int N, Worker *p)
{
    printf("insira o nome do funcionario: ");
    int id = get_worker_position_by_name(N, p);
    if (id == -1)
    {
        printf("\nNao encontrado\n");
    }
    else
    {
        print_worker(p[id]);
    }
    wait();
}
// lista o numero de funcionarios pelo n° de salarios minimos
void wage_report(int N, Worker *p)
{
    int a = 0, b = 0, c = 0; // contadores: 1 ou menos, 1 a 3 salarios minimos, mais de 3 salarios minimos respectivamente
    float MW = 1.320;        // salario minimo

    for (size_t i = 0; i < N; i++)
    {
        if (p[i].wage <= MW)
        {
            a++;
        }
        else if (p[i].wage > MW && p[i].wage <= MW * 3)
        {
            b++;
        }
        else if (p[i].wage > MW * 3)
        {
            c++;
        }
    }
    printf("%i recebe(m) 1 salario minimo ou menos\n  %i recebe(m) 1 a 3 salarios minimos \n %i recebe(m) mais de 3 salarios minimos", a, b, c);
}