#include <stdio.h>
#include <stdlib.h>

int main()
{
    char *batata = "batata";
    char *xuxa = "bozo";

    if (*batata == *xuxa)
    {
        printf(batata);
    }
}