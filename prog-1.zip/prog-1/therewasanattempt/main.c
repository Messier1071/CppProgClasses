#include <stdio.h>

int main(int, char**){
    printf("Hello, from xuxa!\n");
}
