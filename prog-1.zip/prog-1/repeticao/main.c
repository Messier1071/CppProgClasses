#include <stdio.h>

#include <stdlib.h> 


void ex2(int n){
    float H = 1;

    for(int i =1; i<=n; i++){
       
        H = H+1/(float)i;

        printf("[%i/%i]:%f\n",n,i,H);//debug
    }   

    printf("/n valor de H: %f",H);
return;
}



int main()
{
    for(int i =1; i<=20; i++){
       
        //todo roleta russa
        

        int a = rand();
        printf("%d\n",a);//debug
    } 
    //system("pause");
    return 0;
}