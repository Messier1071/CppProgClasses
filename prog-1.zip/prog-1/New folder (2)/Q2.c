//ian martins mendes
// 23205319

#include <stdio.h>
#include <stdlib.h>


typedef struct dados_letra {
char letra;
int codigo_tabela_ASCII;
struct dados_letra *proximo;
}Letter;

int menu();

int main(){
    int  choice = -1;
    Letter *list = NULL, *aux = NULL;
    do
    {
        choice = menu();
        switch (choice)
        {
        case 0:
            printf("adios");
            break;
        case 1:
            aux = malloc(sizeof(Letter));
            printf("insira o caractere:");
            scanf("%c", &aux->letra );
            aux->codigo_tabela_ASCII = (int)aux->letra;

            if (list)
            {
                aux->proximo = list;
                list = aux;
            }else
            {
                aux->proximo = NULL;
                list = aux;
            }
            break;
        case 2:
            aux = list;
            while (aux)
            {
                printf("[%c],[%i],[%p]\n",aux->letra,aux->codigo_tabela_ASCII);
                aux = aux->proximo;
            }
            
            break;

        default:
            break;
        }
    } while (choice != 0);
    


    return 0;
}

int menu()
{
    int choice = -1;
    char *options = "opcoes:\n"
                    "0 = sair\n"
                    "1 = cadastrar caractere\n"
                    "2 = ver cadeia\n"
                    "?:";
    printf(options);
    scanf("%i", &choice);
    getchar();
    return choice;
}