//ian martins mendes
// 23205319
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define arrsize 5
/*
todo ler matriz inteira
todo somar diag principal
todo maior valor matriz
todo exportar soma diag principal e o maior valor
!com sua respectiva posicao
*/

typedef struct holdNumWpos
{
    float num;
    int i;
    int j;
} HldN;

void ToPointer(float array[arrsize][arrsize], FILE *out); // podia ter feito por aritmetica de ponteiro
float maindiag(float array[arrsize][arrsize]);            // sim.
HldN highestvalue(float array[arrsize][arrsize]);
int menu();
void Out(float array[arrsize][arrsize]);

int main()
{
    srand(time(NULL));
    int i = 0, j = 0, choice = -1, temp = 0; // i= linha j = colun
    float array[arrsize][arrsize];

    printf("deseja preencher o vetor automaticamente\n0-sim\n1-nao\n?:");
    scanf("%i", &temp);
    getchar();
    for (i = 0; i < arrsize; i++)
    {
        for (j = 0; j < arrsize; j++)
        {
            if (temp == 0)
            {
                array[i][j] = rand() % 100;
            }
            else
            {
                printf("[%i][%i]:", i, j);
                scanf("%f", &array[i][j]);
                getchar();
            }
        }
    }

    do
    {
        choice = menu();
        switch (choice)
        {
        case 0:
            printf("adios");
            break;

        case 1:
            ToPointer(array, stdout);
            break;
        case 2:
            maindiag(array);
            break;
        case 3:
            highestvalue(array);
            break;
        case 4:
            Out(array);
            break;

        default:
            break;
        }
    } while (choice != 0);
    return 0;
}

int menu()
{
    int choice = -1;
    char *options = "opcoes:\n"
                    "0 = sair sem salvar\n"
                    "1 = ver os dados\n"
                    "2 = somar diag principal\n"
                    "3 = encontrar o maior valor\n"
                    "4 = exportar todos os dados\n"
                    "?:";
    printf(options);
    scanf("%i", &choice);
    getchar();
    return choice;
}

void ToPointer(float array[arrsize][arrsize], FILE *out)
{
    int i = 0, j = 0;
    for (i = 0; i < arrsize; i++)
    {
        for (j = 0; j < arrsize; j++)
        {
            fprintf(out, "[%4.1f] ", array[i][j]);
        }
        fprintf(out, "\n");
    }
}

float maindiag(float array[arrsize][arrsize])
{
    int i = 0, j = 0;
    float hold = 0;
    for (i = 0; i < arrsize; i++)
    {
        for (j = 0; j < arrsize; j++)
        {
            if (i == j)
            {
                hold = hold + array[i][j];
            }
        }
    }
    printf("[%4.1f]\n", hold);
    return hold;
}

HldN highestvalue(float array[arrsize][arrsize])
{
    int i = 0, j = 0;
    HldN hold;
    for (i = 0; i < arrsize; i++)
    {
        for (j = 0; j < arrsize; j++)
        {
            if (array[i][j] > hold.num)
            {
                hold.num = array[i][j];
                hold.i = i;
                hold.j = j;
            }
        }
    }
    printf("Num = [%4.1f]\ni = [%1i]\nj = [%1i]\n", hold.num, hold.i, hold.j);
    return hold;
}
void Out(float array[arrsize][arrsize])
{
    FILE *ExportP = NULL;
    ExportP = fopen("Exported.txt", "a");
    HldN temp = highestvalue(array);
    fprintf(ExportP, "=========================================\n");
    ToPointer(array, ExportP);
    fprintf(ExportP, "Valor da diagonal principal:......[%5.1f]\n", maindiag(array));
    fprintf(ExportP, "maior valor [%4.1f] na posicao [%i][%i]", temp.num, temp.i, temp.j);
    fflush(ExportP);
    fclose(ExportP);
}