// ian martins mendes
//  23205319
#include <stdio.h>
#include <stdlib.h>

int main()
{
    int size = 0, *array = NULL, i = 0,j = 0,flag = 0;
    printf("digite o tamanho do vetor:");
    scanf("%i", &size);
    getchar();
    array = malloc(sizeof(int) * size);
    for ( i = 0; i < size; i++)
    {
        scanf("%i", &array[i]);
        getchar();
    }
    for ( i = 0; i < size; i++)
    {
        flag = 0;
        for ( j = 2; j < array[i]; j++)
        {
            //printf("\n%ie%i %i\n",array[i],j,array[i]%j);
            if (array[i]%j==0)
            {
                
                flag = 1;
            }
            
        }
        if(flag == 0){
            printf("[%i] e primo\n",i);
        }else
        {
            printf("[%i] nao primo\n",i);
        }
        
        
    }

}