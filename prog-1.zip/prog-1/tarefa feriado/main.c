#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <conio.h>
#define lmt 10

int main()
{
    // startup();
    char name[lmt];   // Nome
    int stock[lmt];   // Estoque
    float price[lmt]; // preço
    int c;
    int nproducts = 0;
    const char *options =
        "0 - sair\n"
        "1 - cadastrar um produto \n"
        "2 - Ver todos os produtos\n"
        "3 - pesquisar pelo nome\n"
        "4 - ver produto mais caro\n"
        "5 - ver produto mais barato\n"
        "6 - ver produto com maior estoque\n"
        "7 - ver produto com menor estoque\n"
        "8 - calcular valor do estoque da empresa\n";
    int opt;
    int ct = 0;

    // startup end

    do
    {

        printf(options);
        scanf("%i", &opt);
        switch (opt)
        {
        case 0:
            ct = 1;
            break;

        case 1: // cadastro
            if (nproducts == lmt)
            {
                printf("database cheio");
            }
            else
            {
                printf("insira o produto para o ID %d \n", nproducts);

                printf("\"Nome\":");
                scanf(" %c", &name[nproducts]);

                printf("Estoque:");
                scanf(" %d", &stock[nproducts]);

                printf("Preço:");
                scanf(" %f", &price[nproducts]);

                printf("\n");
                nproducts++;
            }
            break;

        case 2: // ver todos os produtos
            if (nproducts != 0)
            {
                printf("\n");
                for (c = 0; c < nproducts; c++)
                {
                    printf("ID: %d \n", c);
                    printf("\"Nome\":%c\n", name[c]);
                    printf("Estoque:%d\n", stock[c]);
                    printf("Preço:%f\n", price[c]);
                    printf("------------------------\n");
                }
                printf("\n");
            }
            else
            {
                printf("\ndatabase vazio\n");
            }

            break;

        case 3: // pesquisar pelo nome
            if (nproducts != 0)
            {
                char tname;
                printf("insira uma letra para pesquisar:");
                scanf(" %c", &tname);
                for (c = 0; c < nproducts; c++)
                {
                    if (name[c] == tname)
                    {
                        printf("ID[%i]\n\n", c);
                        break;
                    }
                }
            }
            else
            {
                printf("\ndatabase vazio\n");
            }
            break;

        case 4: // mais caro

            if (nproducts != 0)
            {
                float bigprice = 0;
                for (c = 0; c <= nproducts; c++)
                {
                    if (price[c] > bigprice)
                    {
                        bigprice = price[c];
                    }
                }
                for (c = 0; c < nproducts; c++)
                {
                    if (price[c] == bigprice)
                    {
                        printf("\nID[%i] e o mais caro\n", c);
                        break;
                    }
                }
            }
            else
            {
                printf("\nempty database\n");
            }
            break;

        case 5: // menor preco
            if (nproducts != 0)
            {
                float Min_price = price[0];
                for (int counter = 0; counter < nproducts; counter++)
                {
                    if (price[counter] < Min_price)
                    {
                        Min_price = price[counter];
                    }
                }
                for (int counter2 = 0; counter2 < nproducts; counter2++)
                {
                    if (price[counter2] == Min_price)
                    {
                        printf("ID[%i]=%f", counter2, Min_price);
                    }
                }
            }
            else
            {
                printf("\nempty database\n");
            }
            break;

        case 6: // maior estoque
            if (nproducts != 0)
            {
                int Max_stock = stock[0];
                for (int counter = 0; counter < nproducts; counter++)
                {
                    if (stock[counter] > Max_stock)
                    {
                        Max_stock = stock[counter];
                    }
                }
                for (int counter2 = 0; counter2 < nproducts; counter2++)
                {
                    if (stock[counter2] == Max_stock)
                    {
                        printf("ID[%i]=%i\n\n", counter2, Max_stock);
                    }
                }
            }
            else
            {
                printf("\nempty database\n");
            }
            break;

        case 7: // menor estoque
            if (nproducts != 0)
            {
                int Min_stock = stock[0];
                for (int counter = 0; counter < nproducts; counter++)
                {
                    if (stock[counter] < Min_stock)
                    {
                        Min_stock = stock[counter];
                    }
                }
                for (int counter2 = 0; counter2 < nproducts; counter2++)
                {
                    if (stock[counter2] == Min_stock)
                    {
                        printf("ID[%i]=%i\n\n", counter2, Min_stock);
                    }
                }
            }
            else
            {
                printf("\nempty database\n");
            }
            break;
        case 8:
            if (nproducts != 0)
            {
                float TotalPrice = 0;
                for (int counter = 0; counter < nproducts; counter++)
                {

                    TotalPrice = TotalPrice + (price[counter] * (float)stock[counter]);
                }
                printf("valor do estoque da empresa:%f", TotalPrice);
            }
            else
            {
                printf("\nempty database\n");
            }
            break;

        default:
            break;
        }
    } while (ct == 0);

    // system("pause");
}
