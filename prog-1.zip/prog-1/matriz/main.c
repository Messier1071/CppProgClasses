#include <stdio.h>
#include <stdlib.h>
#define T 25

int main()
{

    int m[T][T];
    int t = 1;
    for (int i = 0; i < T; i++)
    {

        for (int j = 0; j < T; j++)
        {
            printf("M[%i][%i]:", i, j);
            // scanf(" %i", &m[i][j]);

            m[i][j] = t;
            t++;
        }
    }
    printf("\n\n\n");

    int b;
    for (int i = 0; i < T; i++)
    {

        b = m[2][i];
        m[2][i] = m[4][i];
        m[4][i] = b;
    }

    for (int i = 0; i < T; i++)
    {

        b = m[i][1];
        m[i][1] = m[i][3];
        m[i][3] = b;
    }

    int tmp[T];
    for (int i = 0; i < T; i++)
    {

        for (int j = 0; j < T; j++)
        {
            if (i == j)
            {
                tmp[i] = m[i][j];
            }
        }
    }
    // 1 9 23 17 15

    for (int i = 0; i < T; i++)
    {

        for (int j = 0; j < T; j++)
        {
            if ((i + j) == (T - 1))
            {
                m[i][i] = m[i][j];
                m[i][j] = tmp[i];
            }
        }
    }
    system("cls");
    // todo trocar a linha 3 com a coluna 2

    for (int i = 0; i < T; i++)
    {

        for (int j = 0; j < T; j++)
        {

            printf("[%3i]", m[i][j]);
        }
        printf("\n");
    }
    system("pause");
}