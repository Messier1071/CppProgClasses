#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

int main()
{
    char a;

    while (a == a)
    {
        a = getch();
        Beep(((int)a ^ 2), 200);
    }
}